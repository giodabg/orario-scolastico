#include "GiornoSettimana.h"
#include "Classe.h"
#include "Aula.h"
#include "Materia.h"

class Lezione {
    private:
        GiornoSettimana giorno;
        int ora; 
        vector docenti; 
        Classe* classe; /
        Aula* aula; 
        Materia* materia; 

    public:
        Lezione();
        Lezione(GiornoSettimana giorno, int ora, vector docenti, Classe* classe, Aula* aula, Materia* materia);
        ~Lezione();

        bool Sovrapposta(const Lezione& altra) const; // Verifica se due lezioni nello stesso giorno occupano la stessa ora
        void spostaLezione(std::string nuovoGiorno, int nuovaOra); // Sposta la lezione in un altra ora
        void assegnaAula(std::string idNuovaAula); // Cambia l'aula della lezione
        bool aggiungiDocente(Docente* d); // Aggiunge un docente
        bool rimuoviDocente(std::string idDocente); // Rimuove un docente dalla lezione

        void toString();
        void toCSV();
        void fromCSV();
        void toXML(){
            cout << "<Lezione>" << endl;
            cout << "    <Giorno>" << toString(giorno) << "</Giorno>" << endl;
            cout << "    <Ora>" << ora << "</Ora>" << endl;
            cout << "    <MateriaRef id=\"" << materia->getId() << "\"/>" << endl;
            cout << "    <AulaRef id=\"" << aula->getId() << "\"/>" << endl;
            cout << "    <ClasseRef id=\"" << classe->getId() << "\"/>" << endl;
            cout << "    <Docenti>" << endl;
            for (int i = 0; i < docenti.size(); i++) { //scrive gli id in base al numero di docentl
                cout << "        <DocenteRef id=\""
                    << docenti[i]->getId()
                    << "\"/>" << endl;
            }
            cout << "    </Docenti>" << endl;
            cout << "</Lezione>" << endl;
        }
        void fromXML();

};
