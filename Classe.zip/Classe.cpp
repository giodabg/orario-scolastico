#include "GiornoSettimana.h"
#include "Classe.h"
#include "Aula.h"
#include "Materia.h"

class Classe {
    private:
        int id; // es. 1, 4
        std::string codice; // es. "3AINF", "5BCHI"
        int numeroStudenti; // es. 22, 27
        vector studenti; // es. [Luigi, Carlo]
        vector lezioni; // es. [Lun1, Lun2]

    public:

        Classe();
        Classe(int id, std::string codice, int numeroStudenti, vector studenti, vector lezioni);
        ~Classe();

        void aggiungiStudente(Studente* s); // Inserisce un nuovo studente (Awais Mohamed)
        void rimuoviStudente(); // Rimuove uno studente (Debabia || Cristain Botezatu Madalin)
        void associaLezione(Lezione* l); // Collega una lezione alla classe

        void toString();
        void toCSV();
        void fromCSV();
        void toXML(){
            cout << "<Classe id=\"CLA-" << id << "\">" << endl;
            cout << "    <Codice>" << codice << "</Codice>" << endl; //stampe indentate con gli spazi (prob c'è un metodo migliore boh)
            cout << "    <NumeroStudenti>" << numeroStudenti << "</NumeroStudenti>" << endl;
            cout << "    <LezioniAssegnate>" << endl;
            for (int i = 0; i < lezioni.size(); i++) { //stessa roba dei prof ma cvon lezioni
                cout << "        <LezioneRef id=\""
                    << lezioni[i]->getId()
                    << "\"/>" << endl;
            }
            cout << "    </LezioniAssegnate>" << endl;
            cout << "</Classe>" << endl; 
        }
        void fromXML();

};